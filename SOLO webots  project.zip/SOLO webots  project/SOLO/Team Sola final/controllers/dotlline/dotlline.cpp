#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>
// All the webots classes are defined in the "webots" namespace
using namespace webots;

#define Time_Step 16
#define Max_Speed 10

double ir0_val;
double ir1_val;
double ir2_val;
double ir3_val;
double ir4_val;
double ir5_val;

double ir6_val;
double ir7_val;
double ir8_val;
double ir9_val;

double get_error(){
    return  (3*ir0_val+2*ir1_val+ir2_val-ir3_val-2*ir4_val-3*ir5_val)/30;
}

double get_error2(){
    return  (2*ir6_val+ir7_val-ir8_val-2*ir9_val)/30;
}

int main(int argc, char **argv) {
  // create the Robot instance.
  Robot *robot = new Robot();
  Motor *leftMotor =robot->getMotor("motor2");
  Motor *rightMotor =robot->getMotor("motor1");
  
  leftMotor->setPosition(INFINITY);
  rightMotor->setPosition(INFINITY);
  
  //ir sensors
  DistanceSensor *ir0 = robot-> getDistanceSensor("ir0"); 
  DistanceSensor *ir1 = robot-> getDistanceSensor("ir1"); 
  DistanceSensor *ir2 = robot-> getDistanceSensor("ir2"); 
  DistanceSensor *ir3 = robot-> getDistanceSensor("ir3"); 
  DistanceSensor *ir4 = robot-> getDistanceSensor("ir4"); 
  DistanceSensor *ir5 = robot-> getDistanceSensor("ir5"); 
  
  DistanceSensor *ir6 = robot-> getDistanceSensor("ir6"); 
  DistanceSensor *ir7 = robot-> getDistanceSensor("ir7"); 
  DistanceSensor *ir8 = robot-> getDistanceSensor("ir8"); 
  DistanceSensor *ir9 = robot-> getDistanceSensor("ir9"); 
 
  
  ir0->enable(Time_Step);
  ir1->enable(Time_Step);
  ir2->enable(Time_Step);
  ir3->enable(Time_Step);
  ir4->enable(Time_Step);
  ir5->enable(Time_Step);
  
  ir6->enable(Time_Step);
  ir7->enable(Time_Step);
  ir8->enable(Time_Step);
  ir9->enable(Time_Step);
  
 
  while (robot->step(Time_Step) != -1) {
    
  ir0_val= ir0->getValue();
  ir1_val= ir1->getValue();
  ir2_val= ir2->getValue();
  ir3_val= ir3->getValue();
  ir4_val= ir4->getValue();
  ir5_val= ir5->getValue();
  
  
  ir6_val= ir0->getValue();
  ir7_val= ir1->getValue();
  ir8_val= ir2->getValue();
  ir9_val= ir3->getValue();
  
  // Digitalization
   if(ir0_val>700){
    ir0_val = 0;
    }else{
    ir0_val = 1;
    }
    if(ir1_val>700){
    ir1_val = 0;
    }else{
    ir1_val = 1;
    }
    if(ir2_val>700){
    ir2_val = 0;
    }else{
    ir2_val = 1;
    }
    if(ir3_val>700){
    ir3_val = 0;
    }else{
    ir3_val = 1;
    }
    if(ir4_val>700){
    ir4_val = 0;
    }else{
    ir4_val = 1;
    }
    if(ir5_val>700){
    ir5_val = 0;
    }else{
    ir5_val = 1;
    }
    
    
    if(ir6_val>700){
    ir6_val = 0;
    }else{
    ir6_val = 1;
    }
    if(ir7_val>700){
    ir7_val = 0;
    }else{
    ir7_val = 1;
    }
    if(ir8_val>700){
    ir8_val = 0;
    }else{
    ir8_val = 1;
    }
    if(ir9_val>700){
    ir9_val = 0;
    }else{
    ir9_val = 1;
    }
  //PID parametres for line following
  double error= get_error();
  double last_error = 0;
  double derivative = error - last_error;
  last_error = error;
  
  //PID parametres for line following
  double error2= get_error2();
  double last_error2 = 0;
  double derivative2 = error2 - last_error2;
  last_error2 = error2;
  if(ir0_val ==0 && ir1_val == 0 && ir2_val == 0 && ir3_val == 0 && ir4_val ==0  && ir5_val == 0){
      leftMotor->setVelocity(3-25*error2-45*derivative2);
      rightMotor->setVelocity(3+25*error2+45*derivative2);
  }else{
      leftMotor->setVelocity(3-25*error-45*derivative);
      rightMotor->setVelocity(3+25*error+45*derivative);
  }
  
}
  delete robot;
  return 0;
  
}