#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>

using namespace webots;

#define Max_Speed 10

// All the webots classes are defined in the "webots" namespace


int main(int argc, char **argv) {
  Robot *robot = new Robot();
  
  Motor *leftMotor = robot->getMotor("motor2");
  Motor *rightMotor = robot->getMotor("motor1");
  
  leftMotor->setPosition(INFINITY);
  rightMotor->setPosition(INFINITY);
  
  DistanceSensor *ds_right = robot->getDistanceSensor("ds_right");
  DistanceSensor *ds_left = robot->getDistanceSensor("ds_left");

  // get the time step of the current world.
  int timeStep = (int)robot->getBasicTimeStep();
  
  ds_right->enable(timeStep);
  ds_left->enable(timeStep);
 
  while (robot->step(timeStep) != -1) {

    double ds_right_val = ds_right->getValue();
    double ds_left_val = ds_left->getValue();
    
   // PID parameters for right motor
    double target =60;
    double last_wr_error = 0;
    double r_position = ds_right_val;
    double wr_error = (r_position - target)/10;
    double wr_derivative = wr_error - last_wr_error;
    last_wr_error = wr_error;
    
   //PID parametres for left motor 
    double last_wl_error = 0;
    double l_position = ds_left_val;
    double wl_error = (l_position - target)/10;
    double wl_derivative = wl_error - last_wl_error;
    last_wl_error = wl_error;
    
    if ((ds_right_val <500)&&(ds_left_val==1000)){
    std::cout << "ds_left: " << ds_left_val <<std::endl;
    std::cout << "ds_right: " << ds_right_val <<std::endl;
    std::cout << "wr_error: " << wr_error <<std::endl;
    leftMotor->setVelocity(2+0.015*wr_error+ 0.2*wr_derivative);
    rightMotor->setVelocity(2-0.015*wr_error-0.2*wr_derivative);
    }
    else if ((ds_right_val <500)&&(ds_left_val< 500)){
    std::cout << "ds_left: " << ds_left_val <<std::endl;
    std::cout << "ds_right: " << ds_right_val <<std::endl;
    std::cout << "wr_error: " << wr_error <<std::endl;
    leftMotor->setVelocity(2+0.02*wr_error+ 0.5*wr_derivative);
    rightMotor->setVelocity(2-0.02*wr_error-0.5*wr_derivative);
    //std::cout << "wl_error: " << wl_error <<std::endl;
    //leftMotor->setVelocity(2+0.01*wl_error+0.1*wl_derivative);
    //rightMotor->setVelocity(2-0.01*wl_error-0.1*wl_derivative);
    }
    else if((ds_right_val ==1000)&&(ds_left_val<500)){   
    std::cout << "ds_left: " << ds_left_val <<std::endl;
    std::cout << "ds_right: " << ds_right_val <<std::endl;   
    std::cout << "wl_error: " << wl_error <<std::endl;
    leftMotor->setVelocity(2-0.015*wl_error-0.2*wl_derivative);
    rightMotor->setVelocity(2+0.015*wl_error+0.2*wl_derivative);
    }
    else{
    std::cout << "ds_left: " << ds_left_val <<std::endl;
    std::cout << "ds_right: " << ds_right_val <<std::endl;
    leftMotor->setVelocity(2);
    rightMotor->setVelocity(2);
    }
    
    
    
  
  }

  delete robot;
  return 0;
}