#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>
#include <iostream>
#include <webots/PositionSensor.hpp>
#include <windows.h>
// All the webots classes are defined in the "webots" namespace
using namespace webots;

#define Time_Step 32
#define Max_Speed 10

double ir0_val;
double ir1_val;
double ir2_val;
double ir3_val;
double ir4_val;
double ir5_val;

double ir_left_val;
double ir_right_val;

double ps1_val;
double ps2_val;

double ds_left_val;
double ds_right_val;





//double meterperrad = 0.04;
//double radperdeg = 0.052;

double get_error(){
    return  (3*ir0_val+2*ir1_val+ir2_val-ir3_val-2*ir4_val-3*ir5_val)/30;
}


int main(int argc, char **argv) {
  // create the Robot instance.
  Robot *robot = new Robot();
  Motor *leftMotor =robot->getMotor("motor2");
  Motor *rightMotor =robot->getMotor("motor1");
  
  //Position sensors
  PositionSensor *ps1 = robot->getPositionSensor("psensor1");
  PositionSensor *ps2 = robot->getPositionSensor("psensor2");
  ps1->enable(Time_Step);
  ps2->enable(Time_Step);
  
  leftMotor->setPosition(INFINITY);
  rightMotor->setPosition(INFINITY);
  
  //ir sensors
  DistanceSensor *ir0 = robot-> getDistanceSensor("ir0"); 
  DistanceSensor *ir1 = robot-> getDistanceSensor("ir1"); 
  DistanceSensor *ir2 = robot-> getDistanceSensor("ir2"); 
  DistanceSensor *ir3 = robot-> getDistanceSensor("ir3"); 
  DistanceSensor *ir4 = robot-> getDistanceSensor("ir4"); 
  DistanceSensor *ir5 = robot-> getDistanceSensor("ir5"); 
  
  DistanceSensor *ir_left = robot-> getDistanceSensor("ir_left"); 
  DistanceSensor *ir_right = robot-> getDistanceSensor("ir_right"); 
  
    DistanceSensor *ds_left = robot-> getDistanceSensor("ds_left"); 
  DistanceSensor *ds_right = robot-> getDistanceSensor("ds_right"); 
  
  
  
  ir0->enable(Time_Step);
  ir1->enable(Time_Step);
  ir2->enable(Time_Step);
  ir3->enable(Time_Step);
  ir4->enable(Time_Step);
  ir5->enable(Time_Step);
  
  ir_left->enable(Time_Step);
  ir_right->enable(Time_Step);
  
  ds_left->enable(Time_Step);
  ds_right->enable(Time_Step);
  
  
  // get the time step of the current world.
 int timeStep = (int)robot->getBasicTimeStep();



  while (robot->step(timeStep) != -1) {
 
 
  ds_left_val= ds_left->getValue();
  ds_right_val= ds_right->getValue();
  
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);
  if (429<ds_right_val && ds_right_val<860){
  
   std::cout<<"BOX DETECTED\n";
  
  }
  
  else if  (429>ds_right_val){
  
   std::cout<<"BOX DETECTED inside\n";
  
  
  }
   std::cout<<"left  sensor - ";
   std::cout<<ds_left_val;
   std::cout<<"\n";
   std::cout<<"right sensor - ";
    std::cout<<ds_right_val;
    std::cout<<"\n";
 
}
  delete robot;
  return 0;
}
