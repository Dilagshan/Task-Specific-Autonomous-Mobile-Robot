#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>
#include <iostream>
#include <webots/PositionSensor.hpp>
#include <windows.h>
#include <webots/InertialUnit.hpp>
// All the webots classes are defined in the "webots" namespace

int maze=0;
int box=0;
int pick=0;
int level=0; 
int dot_line=1;
double ramp=0;
int pillar=0;
int gate=0;
int right=2;

int diff=2;
int pillar_count=0;
using namespace webots;

#define Time_Step 16
#define Max_Speed 10

double ir0_val;
double ir1_val;
double ir2_val;
double ir3_val;
double ir4_val;
double ir5_val;

double ir6_val;
double ir7_val;
double ir8_val;
double ir9_val;

double ir_left_val;
double ir_right_val;

double ps1_val;
double ps2_val;

double ds_val;
double ds_left_val;
double ds_right_val;

double ds_front_val;

// create the Robot instance.
Robot *robot = new Robot();
Motor *leftMotor =robot->getMotor("motor2");
Motor *rightMotor =robot->getMotor("motor1");
DistanceSensor *ds_left = robot-> getDistanceSensor("ds_left"); 
DistanceSensor *ds_right = robot-> getDistanceSensor("ds_right"); 
DistanceSensor *ds_front = robot-> getDistanceSensor("ds_front"); 
// get the time step of the current world.
int timeStep = (int)robot->getBasicTimeStep();




//double meterperrad = 0.04;
//double radperdeg = 0.052;
void right_turn(int i,int s){
  std::cout<<"right turn\n";
  double j=0;
  while (robot->step(timeStep) != -1) {
    j++;
    leftMotor->setVelocity(s);
    rightMotor->setVelocity(-s);
    if (j==i){
      break;
    }
  }
}



void left_turn(int i,int s){
  std::cout<<"left turn\n";
  double j=0;
  while (robot->step(timeStep) != -1) {
    j++;
    leftMotor->setVelocity(-s);
    rightMotor->setVelocity(s);
    if (j==i){
      break;
    }
  }
}


void forward(int i,int rs, int ls){
  std::cout<<"forward function\n";
  int j=0;
   while (robot->step(timeStep) != -1) {
      j++;
      leftMotor->setVelocity(ls);
      rightMotor->setVelocity(rs);
      if (j==i){
        break;
      }  
   }
}


 

double get_error(){
    return  (3*ir0_val+2*ir1_val+ir2_val-ir3_val-2*ir4_val-3*ir5_val)/30;
}

double get_error2(){
    return  (2*ir6_val+ir7_val-ir8_val-2*ir9_val)/30;
}

void LineFollowing(){
  double error= get_error();
  double last_error = 0;
  double derivative = error - last_error;
  last_error = error;
  
  leftMotor->setVelocity(3-25*error-45*derivative);
  rightMotor->setVelocity(3+25*error+45*derivative);

}

// Wall following
void WallFollowing(){
   // PID parameters for right motor
    double target =60;
    double last_wr_error = 0;
    double r_position = ds_right_val;
    double wr_error = (r_position - target)/10;
    double wr_derivative = wr_error - last_wr_error;
    last_wr_error = wr_error;
    
   //PID parametres for left motor 
    double last_wl_error = 0;
    double l_position = ds_left_val;
    double wl_error = (l_position - target)/10;
    double wl_derivative = wl_error - last_wl_error;
    last_wl_error = wl_error;
    
    if ((ds_right_val <500)&&(ds_left_val==1000)){

    leftMotor->setVelocity(2+0.015*wr_error+ 0.2*wr_derivative);
    rightMotor->setVelocity(2-0.015*wr_error-0.2*wr_derivative);
    }
    else if ((ds_right_val <500)&&(ds_left_val< 500)){

    leftMotor->setVelocity(2+0.02*wr_error+ 0.5*wr_derivative);
    rightMotor->setVelocity(2-0.02*wr_error-0.5*wr_derivative);
   
    }
    else if((ds_right_val ==1000)&&(ds_left_val<500)){   
 
    leftMotor->setVelocity(2-0.015*wl_error-0.2*wl_derivative);
    rightMotor->setVelocity(2+0.015*wl_error+0.2*wl_derivative);
    }
    else{
    leftMotor->setVelocity(2);
    rightMotor->setVelocity(2);
    }
}

void box_checking(){
  double i=0;
  while (robot->step(timeStep) != -1) {
    i++;
    std::cout<<"CHECKING THE BOX\n";
    leftMotor->setVelocity(-1);
    rightMotor->setVelocity(1);
    
    ds_left_val = ds_left->getValue();
    ds_right_val = ds_right-> getValue();
  
    if (i==39){
    break;
    } 
} 
double p=0;
 while (robot->step(timeStep) != -1) {
p++;
  std::cout<<"CHECKING THE BOX\n";
  ds_left_val = ds_left->getValue();
  ds_right_val = ds_right-> getValue();
  leftMotor->setVelocity(1);
  rightMotor->setVelocity(-1);
  
 //IF BOX IS DETECTED 
 if( 430<ds_left_val && ds_left_val<1000){
   std::cout<<"box detected\n";
   box++;
   forward(34,5,5);
   left_turn(45,5);
   break;
}
  if (p==39){
  break;
  }
}

}

void DashedLineFollowing(){
  //PID parametres for line following
  double error= get_error();
  double last_error = 0;
  double derivative = error - last_error;
  last_error = error;
  
  //PID parametres for line following
  double error2= get_error2();
  double last_error2 = 0;
  double derivative2 = error2 - last_error2;
  last_error2 = error2;
  if(ir0_val ==0 && ir1_val == 0 && ir2_val == 0 && ir3_val == 0 && ir4_val ==0  && ir5_val == 0){
      leftMotor->setVelocity(3-25*error2-45*derivative2);
      rightMotor->setVelocity(3+25*error2+45*derivative2);
  }
  else{
      leftMotor->setVelocity(3-25*error-45*derivative);
      rightMotor->setVelocity(3+25*error+45*derivative);
  }




}

int main(int argc, char **argv) {

  
  //Position sensors
  PositionSensor *ps1 = robot->getPositionSensor("psensor1");
  PositionSensor *ps2 = robot->getPositionSensor("psensor2");
  ps1->enable(Time_Step);
  ps2->enable(Time_Step);
  
  leftMotor->setPosition(INFINITY);
  rightMotor->setPosition(INFINITY);
  
  //ir sensors
  DistanceSensor *ir0 = robot-> getDistanceSensor("ir0"); 
  DistanceSensor *ir1 = robot-> getDistanceSensor("ir1"); 
  DistanceSensor *ir2 = robot-> getDistanceSensor("ir2"); 
  DistanceSensor *ir3 = robot-> getDistanceSensor("ir3"); 
  DistanceSensor *ir4 = robot-> getDistanceSensor("ir4"); 
  DistanceSensor *ir5 = robot-> getDistanceSensor("ir5"); 
  
  DistanceSensor *ir6 = robot-> getDistanceSensor("ir6"); 
  DistanceSensor *ir7 = robot-> getDistanceSensor("ir7"); 
  DistanceSensor *ir8 = robot-> getDistanceSensor("ir8"); 
  DistanceSensor *ir9 = robot-> getDistanceSensor("ir9"); 
  
  DistanceSensor *ir_left = robot-> getDistanceSensor("ir_left"); 
  DistanceSensor *ir_right = robot-> getDistanceSensor("ir_right"); 
  InertialUnit *iu=robot-> getInertialUnit("iu");
  

  ir0->enable(Time_Step);
  ir1->enable(Time_Step);
  ir2->enable(Time_Step);
  ir3->enable(Time_Step);
  ir4->enable(Time_Step);
  ir5->enable(Time_Step);
  
  ir6->enable(Time_Step);
  ir7->enable(Time_Step);
  ir8->enable(Time_Step);
  ir9->enable(Time_Step);
  
  
  ir_left->enable(Time_Step);
  ir_right->enable(Time_Step);
  
  ds_left->enable(Time_Step);
  ds_right->enable(Time_Step);
  ds_front->enable(Time_Step);
  
  iu->enable(Time_Step);
  



  while (robot->step(timeStep) != -1) {
 
    ir0_val= ir0->getValue();
    ir1_val= ir1->getValue();
    ir2_val= ir2->getValue();
    ir3_val= ir3->getValue();
    ir4_val= ir4->getValue();
    ir5_val= ir5->getValue();
    
    ir6_val= ir0->getValue();
    ir7_val= ir1->getValue();
    ir8_val= ir2->getValue();
    ir9_val= ir3->getValue();
    
    ir_left_val= ir_left->getValue();
    ir_right_val= ir_right->getValue();
    ps1_val = ps1->getValue();
    ps2_val = ps2->getValue();
    
    ds_left_val = ds_left->getValue();
    ds_right_val = ds_right-> getValue();
    ds_front_val = ds_front-> getValue();
    const double* angle_val=iu->getRollPitchYaw();
    
    // Digitalization
     if(ir0_val>700){
      ir0_val = 0;
      }else{
      ir0_val = 1;
      }
      if(ir1_val>700){
      ir1_val = 0;
      }else{
      ir1_val = 1;
      }
      if(ir2_val>700){
      ir2_val = 0;
      }else{
      ir2_val = 1;
      }
      if(ir3_val>700){
      ir3_val = 0;
      }else{
      ir3_val = 1;
      }
      if(ir4_val>700){
      ir4_val = 0;
      }else{
      ir4_val = 1;
      }
      if(ir5_val>700){
      ir5_val = 0;
      }else{
      ir5_val = 1;
      }
      
      if(ir_left_val>700){
      ir_left_val = 0;
      }else{
     ir_left_val = 1;
      }
      if(ir_right_val>700){
      ir_right_val= 0;
      }else{
      ir_right_val = 1;
      }

if(gate>0){


if (ir0_val ==1 && ir1_val == 1 && ir2_val == 1 && ir3_val == 1 && ir4_val ==1  && ir5_val == 1){
    leftMotor->setVelocity(0);
    rightMotor->setVelocity(0);
    std::cout<<"ds value - "<<ds_front_val<<"\n";
    
    }
  
if (475 < ds_front_val and ds_front_val<570){
 LineFollowing();
}
if (ir_left_val==1 and ir_right_val==1)  {

    leftMotor->setVelocity(0);
    rightMotor->setVelocity(0);

}
    else{
    LineFollowing();}

}


else if (pillar>0){
 if (diff==2){
    ds_val= ds_left-> getValue();
 }
 else if (diff==1){
    ds_val= ds_right-> getValue();
 }
 
 if (50<ds_val && ds_val<150){
    pillar_count++;
    forward(13,5,5);
  }


    std::cout<<"Pillar count - "<<pillar_count<<"\n";

  

  LineFollowing();
  
  if ((diff==2) and (ir_left_val==1)){
     forward(30,5,5);
    left_turn(45,5);
    gate++;
  }
   else if ((diff==1) and (ir_right_val==1)){
     forward(30,5,5);
    right_turn(45,5);
     gate++;
  }
 
 
 }


//Ramp      
else if(ramp>0){
 if (ir0_val == 1 &&ir1_val == 1 && ir2_val == 1 && ir3_val == 1 && ir4_val ==1  && ir5_val == 1){
  // EVEN DIFFERENCE
  if (diff==2){
    std::cout<<"EVEN DIFF left TURN\n";
    forward(30,5,5);
    left_turn(45,5);
   }
 
  //IF ODD DIFFERENCE
 else {
   std::cout<<"odd DIFF right TURN\n";
   forward(30,5,5); 
   right_turn(45,5);
 }
   pillar++;
 }

 else{
   LineFollowing();
 }  
}

//Dashed line following
else if (dot_line>0){
  std::cout<<"Dash line ENTERED\n"; 
  DashedLineFollowing();
  if (angle_val[0]>0.1){
   ramp++;
   std::cout<<"RAMP DETECTED\n";
 
 }
}




 /*
 
 
From start to circle entering
 maze==0
 
 */



}
  delete robot;
  return 0;
}
