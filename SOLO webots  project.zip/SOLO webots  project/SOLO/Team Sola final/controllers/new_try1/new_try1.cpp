#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <cmath>
#include <webots/Camera.hpp>

#define TIME_STEP 64

using namespace webots;

int main() {
  Robot *robot = new Robot();
  bool boxFound = true;
  bool cameraOn = false;
     Motor*mBase = robot->getMotor("base_motor");
   Motor*mTop = robot->getMotor("arm1_motor");
   Motor*mArm = robot->getMotor("arm2_motor");
   Motor*mHand1 = robot->getMotor("r_motor");
   Motor*mHand2 = robot->getMotor("l_motor");
   
   Camera *cm1;
   cm1 = robot-> getCamera("camera1");
   cm1->enable(TIME_STEP); 
   
   Camera *cm2;
   cm2 = robot-> getCamera("camera2");
   cm2->enable(TIME_STEP); 
   
   std::cout <<"fun"<< std::endl;
   int counter = 0;
    const double position_base =-2.2;
    const double position_top = 0.5;
    const double position_arm =0.9;
    //const double position_hand =0.01;
 
  if (boxFound) {
 
    while (robot->step(TIME_STEP) != -1){
 

    
    if (counter==10){
    mBase->setPosition(position_base);
    mHand1->setPosition(-0.3);
    mHand2->setPosition(0.3);
    mTop->setPosition(0);
   counter = counter;
       std::cout << counter << std::endl;
   }
   
    else if (counter==35){
    mTop->setPosition(position_top);
    std::cout << counter << std::endl;
    }
 
    else if (counter==55){
    mArm->setPosition(position_arm);
    std::cout << counter << std::endl;
    }
    
    else if (counter==95){
    mHand1->setPosition(0.03);
    mHand2->setPosition(-0.03);
    
    std::cout << counter << std::endl;
    }
    else if (counter==105){
     mBase->setPosition(0.6);
     
    std::cout << counter << std::endl;
    }
    else if (counter==145){
     mTop->setPosition(-1.45);
     
    std::cout << counter << std::endl;
    }
    
    else if (counter==155){
     mArm->setPosition(0.0);
     cameraOn = true;
     
    std::cout << counter << std::endl;
    }if( cameraOn && counter == 185){
        //front colour detection
         const unsigned char *imF = cm1->getImage();
         const int imF_width = cm1->getWidth();
         const int imF_height = cm1->getHeight();
     
         std::cout<<imF_width<<"....."<<imF_height<<std::endl;
        
        int rtF = 0;
        int gtF = 0;
        int btF = 0;
        for (int x = 0; x < imF_width; x++)
        for (int y = 0; y < imF_height; y++) {
          int r = cm1->imageGetRed(imF, imF_width, x, y);
          int g = cm1->imageGetGreen(imF, imF_width, x, y);
          int b = cm1->imageGetBlue(imF, imF_width, x, y);
          
          rtF = rtF + r;
          gtF = gtF + g;
          btF = btF + b;
          }
       
        std::cout<<rtF<<"..."<<gtF<<"..."<<btF<<std::endl;
        
        if(rtF > gtF && rtF > btF){
          std::cout << "front colour is RED" << std::endl;
       }else if(gtF > rtF && gtF > btF){
        std::cout << "front colour is GREEN" << std::endl;
       }else if(btF > rtF && btF > gtF){
        std::cout << "front colour is BLUE" << std::endl;
     }
     
     
         //bottom colour detection
         const unsigned char *imB = cm2->getImage();
         const int imB_width = cm2->getWidth();
         const int imB_height = cm2->getHeight();
     
         std::cout<<imB_width<<"....."<<imB_height<<std::endl;
        
        int rtB = 0;
        int gtB = 0;
        int btB = 0;
        for (int x = 0; x < imB_width; x++)
        for (int y = 0; y < imB_height; y++) {
          int r = cm2->imageGetRed(imB, imB_width, x, y);
          int g = cm2->imageGetGreen(imB, imB_width, x, y);
          int b = cm2->imageGetBlue(imB, imB_width, x, y);
          
          rtB = rtB + r;
          gtB = gtB + g;
          btB = btB + b;
          }
       btB=btB-50000;
        std::cout<<rtB<<"..."<<gtB<<"..."<<btB<<std::endl;
        
        if(rtB > gtB && rtB > btB){
          std::cout << "bottom colour is RED" << std::endl;
       }else if(gtB > rtB && gtB > btB){
        std::cout << "bottom colour is GREEN" << std::endl;
       }else if(btB > rtB && btB > gtB){
        std::cout << "bottom colour is BLUE" << std::endl;
     }
        break;
     }
    counter ++; 
                     
    }

  }

  delete robot;
  return 0;
}