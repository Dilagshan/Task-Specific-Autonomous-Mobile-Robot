#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>
#include <iostream>
#include <webots/PositionSensor.hpp>
#include <windows.h>
// All the webots classes are defined in the "webots" namespace

int k=0;
int box=0;
int pick=0;
int level=0; //nerthi
using namespace webots;

#define Time_Step 16
#define Max_Speed 10

double ir0_val;
double ir1_val;
double ir2_val;
double ir3_val;
double ir4_val;
double ir5_val;

double ir_left_val;
double ir_right_val;

double ps1_val;
double ps2_val;

double ds_left_val;
double ds_right_val;

double ds_front_val;




//double meterperrad = 0.04;
//double radperdeg = 0.052;

double get_error(){
    return  (3*ir0_val+2*ir1_val+ir2_val-ir3_val-2*ir4_val-3*ir5_val)/30;
}


int main(int argc, char **argv) {
  // create the Robot instance.
  Robot *robot = new Robot();
  Motor *leftMotor =robot->getMotor("motor2");
  Motor *rightMotor =robot->getMotor("motor1");
  
  //Position sensors
  PositionSensor *ps1 = robot->getPositionSensor("psensor1");
  PositionSensor *ps2 = robot->getPositionSensor("psensor2");
  ps1->enable(Time_Step);
  ps2->enable(Time_Step);
  
  leftMotor->setPosition(INFINITY);
  rightMotor->setPosition(INFINITY);
  
  //ir sensors
  DistanceSensor *ir0 = robot-> getDistanceSensor("ir0"); 
  DistanceSensor *ir1 = robot-> getDistanceSensor("ir1"); 
  DistanceSensor *ir2 = robot-> getDistanceSensor("ir2"); 
  DistanceSensor *ir3 = robot-> getDistanceSensor("ir3"); 
  DistanceSensor *ir4 = robot-> getDistanceSensor("ir4"); 
  DistanceSensor *ir5 = robot-> getDistanceSensor("ir5"); 
  
  DistanceSensor *ir_left = robot-> getDistanceSensor("ir_left"); 
  DistanceSensor *ir_right = robot-> getDistanceSensor("ir_right"); 
  
  DistanceSensor *ds_left = robot-> getDistanceSensor("ds_left"); 
  DistanceSensor *ds_right = robot-> getDistanceSensor("ds_right"); 
  DistanceSensor *ds_front = robot-> getDistanceSensor("ds_front"); 
  ir0->enable(Time_Step);
  ir1->enable(Time_Step);
  ir2->enable(Time_Step);
  ir3->enable(Time_Step);
  ir4->enable(Time_Step);
  ir5->enable(Time_Step);
  
  ir_left->enable(Time_Step);
  ir_right->enable(Time_Step);
  
  ds_left->enable(Time_Step);
  ds_right->enable(Time_Step);
  ds_front->enable(Time_Step);
  
  // get the time step of the current world.
 int timeStep = (int)robot->getBasicTimeStep();



  while (robot->step(timeStep) != -1) {
 
  ir0_val= ir0->getValue();
  ir1_val= ir1->getValue();
  ir2_val= ir2->getValue();
  ir3_val= ir3->getValue();
  ir4_val= ir4->getValue();
  ir5_val= ir5->getValue();
  
  ir_left_val= ir_left->getValue();
  ir_right_val= ir_right->getValue();
  ps1_val = ps1->getValue();
  ps2_val = ps2->getValue();
  
  ds_left_val = ds_left->getValue();
  ds_right_val = ds_right-> getValue();
  ds_front_val = ds_front-> getValue();
  
  // Digitalization
   if(ir0_val>700){
    ir0_val = 0;
    }else{
    ir0_val = 1;
    }
    if(ir1_val>700){
    ir1_val = 0;
    }else{
    ir1_val = 1;
    }
    if(ir2_val>700){
    ir2_val = 0;
    }else{
    ir2_val = 1;
    }
    if(ir3_val>700){
    ir3_val = 0;
    }else{
    ir3_val = 1;
    }
    if(ir4_val>700){
    ir4_val = 0;
    }else{
    ir4_val = 1;
    }
    if(ir5_val>700){
    ir5_val = 0;
    }else{
    ir5_val = 1;
    }
    
    if(ir_left_val>700){
    ir_left_val = 0;
    }else{
   ir_left_val = 1;
    }
    if(ir_right_val>700){
    ir_right_val= 0;
    }else{
    ir_right_val = 1;
    }
     
     


 /*
 
 
From start to circle entering
 k==0
 
 */


if (k==0){


if( ir_right_val== 0 && ir_left_val == 1){


double j=0;
 while (robot->step(timeStep) != -1) {
j++;
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);

if (j==15){
break;

 }
 }
 
 
 
 
 
 
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
 std::cout<<"left  turn\n";
  leftMotor->setVelocity(-5);
  rightMotor->setVelocity(5);
if (i==20){
break;

 }
  std::cout<<"left  turn\n";

 } 
 
 
  
  }  

else if(ir_left_val == 0 && ir_right_val == 1  ){
double j=0;
 while (robot->step(timeStep) != -1) {
j++;
std::cout<<"right turn\n";
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);

if (j==15){
break;

 }
 }
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
std::cout<<"right turn\n";
  leftMotor->setVelocity(+5);
  rightMotor->setVelocity(-5);
if (i==20){
break;

 }
  std::cout<<"right turn\n";
  
 }  
  } 
 
 /*
 
 WALL FOLLOWING
 
 */
 
 else if(ir0_val ==0 && ir1_val == 0 && ir2_val == 0 && ir3_val == 0 && ir4_val ==0  && ir5_val == 0 && ir_left_val==0 && ir_right_val==0) {
 // PID parameters for right motor
    double target =60;
    double last_wr_error = 0;
    double r_position = ds_right_val;
    double wr_error = (r_position - target)/10;
    double wr_derivative = wr_error - last_wr_error;
    last_wr_error = wr_error;
    
   //PID parametres for left motor 
    double last_wl_error = 0;
    double l_position = ds_left_val;
    double wl_error = (l_position - target)/10;
    double wl_derivative = wl_error - last_wl_error;
    last_wl_error = wl_error;
    
    if ((ds_right_val <500)&&(ds_left_val==1000)){
    std::cout << "ds_left: " << ds_left_val <<std::endl;
    std::cout << "ds_right: " << ds_right_val <<std::endl;
    std::cout << "wr_error: " << wr_error <<std::endl;
    leftMotor->setVelocity(2+0.015*wr_error+ 0.2*wr_derivative);
    rightMotor->setVelocity(2-0.015*wr_error-0.2*wr_derivative);
    }
    else if ((ds_right_val <500)&&(ds_left_val< 500)){
    std::cout << "ds_left: " << ds_left_val <<std::endl;
    std::cout << "ds_right: " << ds_right_val <<std::endl;
    std::cout << "wr_error: " << wr_error <<std::endl;
    leftMotor->setVelocity(2+0.02*wr_error+ 0.5*wr_derivative);
    rightMotor->setVelocity(2-0.02*wr_error-0.5*wr_derivative);
   
    }
    else if((ds_right_val ==1000)&&(ds_left_val<500)){   
    std::cout << "ds_left: " << ds_left_val <<std::endl;
    std::cout << "ds_right: " << ds_right_val <<std::endl;   
    std::cout << "wl_error: " << wl_error <<std::endl;
    leftMotor->setVelocity(2-0.015*wl_error-0.2*wl_derivative);
    rightMotor->setVelocity(2+0.015*wl_error+0.2*wl_derivative);
    }
    else{
    std::cout << "ds_left: " << ds_left_val <<std::endl;
    std::cout << "ds_right: " << ds_right_val <<std::endl;
    leftMotor->setVelocity(2);
    rightMotor->setVelocity(2);
    }
 
 
 }
 
 
  

// DETECTING THE CIRCLE ENTRANCE    
else if(ir0_val ==1 && ir1_val == 1 && ir2_val == 1 && ir3_val == 1 && ir4_val ==1  && ir5_val == 1){
 k++;
double j=0;
 while (robot->step(timeStep) != -1) {
j++;
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);

if (j==12){
break;

 }
 }
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
 
  leftMotor->setVelocity(+5);
  rightMotor->setVelocity(-5);
if (i==18){
break;

 }
  std::cout<<"CIRCLE ENTERED\n"; 
 }
 }  
 // NORMAL LINE FOLLOWING BEFORE CIRCLE    
           
else{

     double error= get_error();
  double last_error = 0;
  double derivative = error - last_error;
  last_error = error;
  
  leftMotor->setVelocity(3-25*error-45*derivative);
  rightMotor->setVelocity(3+25*error+45*derivative);
 
 }
}
 

 
 /*
 
 
 CIRCLE MAZE SOLVING
 if k==1: it will start circular maze solving
 
 
 */
 

 
else if (k>0){


//BOX PICKED
if (pick>0){

if (level==3 or level==4){
std::cout<<"level 3\n";

if(ir_right_val==1 && ir_left_val==1 && ir0_val ==1 && ir1_val == 1 && ir2_val == 1 && ir3_val == 1 && ir4_val ==1  && ir5_val == 1){
double j=0;
 while (robot->step(timeStep) != -1) {
j++;
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);

if (j==15){
break;

 }
 }
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
 std::cout<<"right turn after picking\n";
  leftMotor->setVelocity(5);
  rightMotor->setVelocity(-5);
if (i==24){
break;
  }

 
 }
 
  
}

else if (ir_right_val==0 && ir_left_val==1){
 double j=0;
 while (robot->step(timeStep) != -1) {
j++;
std::cout<<"Left turn exit way\n";
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);

if (j==15){
break;

 }
 }
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
std::cout<<"left turn\n";
  leftMotor->setVelocity(-5);
  rightMotor->setVelocity(+5);
if (i==20){
break;

 }
  std::cout<<"left turn\n";
  
 }
 }

else{
  double error= get_error();
  double last_error = 0;
  double derivative = error - last_error;
  last_error = error;
  
  leftMotor->setVelocity(3-25*error-45*derivative);
  rightMotor->setVelocity(3+25*error+45*derivative);

}

}



else{
if(ir_right_val==1 && ir_left_val==1 && ir0_val ==1 && ir1_val == 1 && ir2_val == 1 && ir3_val == 1 && ir4_val ==1  && ir5_val == 1){
double j=0;
 while (robot->step(timeStep) != -1) {
j++;
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);

if (j==15){
break;

 }
 }
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
 std::cout<<"left  turn after picking\n";
  leftMotor->setVelocity(-5);
  rightMotor->setVelocity(5);
if (i==24){
break;
  }

 
 }
 
  
}
else if ((ir_right_val==1 && ir_left_val==0)|| (ir0_val ==1 && ir1_val == 1 && ir2_val == 1 && ir3_val == 1 && ir4_val ==1  && ir5_val == 1)){
 double j=0;
 while (robot->step(timeStep) != -1) {
j++;
std::cout<<"right turn exit way\n";
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);

if (j==15){
break;

 }
 }
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
std::cout<<"right turn\n";
  leftMotor->setVelocity(+5);
  rightMotor->setVelocity(-5);
if (i==20){
break;

 }
  std::cout<<"right turn\n";
  
 }
 }
else if(ir_left_val== 1 && ir_right_val==0 ){
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
  leftMotor->setVelocity(4);
  rightMotor->setVelocity(3);
 std::cout<<"UNWANTED LEFT DETECTED\n"; 
  

  
if (i==13){
break;

 } 
}

}
else{

  double error= get_error();
  double last_error = 0;
  double derivative = error - last_error;
  last_error = error;
  
  leftMotor->setVelocity(3-25*error-45*derivative);
  rightMotor->setVelocity(3+25*error+45*derivative);
 
 }
}
}


//BOX DETECTED
else if( box>0){

if(ds_front_val<100) {
  leftMotor->setVelocity(0);
  rightMotor->setVelocity(0);
  pick++;
}

else{

  double error= get_error();
  double last_error = 0;
  double derivative = error - last_error;
  last_error = error;
  std::cout<<"entered here";


  leftMotor->setVelocity(3-25*error-45*derivative);
  rightMotor->setVelocity(3+25*error+45*derivative);


}

 
  }

// IF EXIT WAY DETECTED BEFORE BOX DETECTION
else if(ir_right_val== 1 || (ir0_val ==1 && ir1_val == 1 && ir2_val == 1 && ir3_val == 1 && ir4_val ==1  && ir5_val == 1) ){
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
  leftMotor->setVelocity(1);
  rightMotor->setVelocity(4);
 std::cout<<"EXIT WAY DETECTED\n"; 
  

  
if (i==30){
break;

 } 
}

}

//BOX CHECKING BY CLOCKWISE AND ANTI CLOCKWISE TURNING

else if(ir_right_val== 0 && ir_left_val == 1  ){
level++; // nerthi
std::cout<<"level :" << level<< "\n"; //nerthi

double i=0;
 while (robot->step(timeStep) != -1) {
i++;
std::cout<<"left clock\n";
 std::cout<<"CHECKING THE BOX\n";
  leftMotor->setVelocity(-1);
  rightMotor->setVelocity(1);
  
   ds_left_val = ds_left->getValue();
  ds_right_val = ds_right-> getValue();
  std::cout<<"measure the distance - ";
  std::cout<<ds_left_val;
  std::cout<<"\n";
  
if (i==25){
break;

 } 
 } 
double p=0;
 while (robot->step(timeStep) != -1) {
p++;
 std::cout<<"ANTICLOCK WISE\n";
  ds_left_val = ds_left->getValue();
  ds_right_val = ds_right-> getValue();
   std::cout<<"measure the distance - ";
  std::cout<<ds_left_val;
  std::cout<<"\n";
  leftMotor->setVelocity(1);
  rightMotor->setVelocity(-1);
  
 //IF BOX IS DETECTED 
 if( 430<ds_left_val && ds_left_val<1000){

 std::cout<<"box detected\n";
 box++;
 
double j=0;
 while (robot->step(timeStep) != -1) {
j++;
   leftMotor->setVelocity(+5);
  rightMotor->setVelocity(+5);

if (j==18){
break;

 }
 }
double i=0;
 while (robot->step(timeStep) != -1) {
i++;
 std::cout<<"left  turn circle\n";
  leftMotor->setVelocity(-5);
  rightMotor->setVelocity(5);
if (i==24){
break;
  }

 
 } 
break;
}
if (p==25){
break;

 }
}

double l=0;
 while (robot->step(timeStep) != -1) {
l++;

  leftMotor->setVelocity(1);
  rightMotor->setVelocity(+1);
  
if (l==20){
break;

 }
 
 } 



}



//lINE FOLLOWING
else{

  double error= get_error();
  double last_error = 0;
  double derivative = error - last_error;
  last_error = error;
  
  leftMotor->setVelocity(3-25*error-45*derivative);
  rightMotor->setVelocity(3+25*error+45*derivative);
 
 }

}




  
}
  delete robot;
  return 0;
}
